// Edit everything here.
// Photos go in /public/photos/<stage id>/1.jpg, 2.jpg, ... (4-5 per stage).
// Missing photos show a "photo coming soon" frame instead of a broken image.

export const NAME = "Vaishnavi";
export const FULL_NAME = "Vaishnavi Shukla";
export const BIRTHDAY = "2026";
export const FROM = "everyone who loves you";

export const INTRO =
  "Twenty-one years of you, so we made you a little scrapbook. Scroll slowly - every page is a chapter we loved watching you write.";

export const FINALE = [
  "Twenty-one years of kindness, laughter, late-night studying, and the courage to chase what sets your heart on fire.",
  "May this year bring you calm exams, loud celebrations, and patients who actually floss.",
  "Grateful for every version of you so far - excited for every version still to come.",
];

export const FINALE_PHOTO = "/photos/finale.jpg";

const pics = (id, captions) => captions.map((caption, i) => ({ src: `/photos/${id}/${i + 1}.jpg`, caption }));

// layout: "scatter" (photos dealt onto the table) | "stack" (deck flicks away) | "reel" (sideways clothesline)
// card:   "letter" | "notebook" | "stamp"
export const stages = [
  {
    id: "tiny-toes",
    title: "Tiny Toes & Big Eyes",
    era: "the little one",
    layout: "scatter",
    card: "letter",
    greeting: "Dear little Vaishnavi,",
    message:
      "Before you could walk, you already owned the room - the softest cheeks, the loudest giggles, and a whole family wrapped around one tiny finger.",
    photos: pics("tiny-toes", ["day one", "those cheeks!", "first steps", "bath-time boss", "nap queen"]),
  },
  {
    id: "pigtails",
    title: "Pigtails & Pencil Boxes",
    era: "the school days",
    layout: "stack",
    card: "notebook",
    message:
      "Two neat plaits, a bag bigger than you, and a brave little wave at the gate. Gold stars, sports days, and stories you never stopped telling.",
    photos: pics("pigtails", ["first day", "sports day", "annual function", "best friend no. 1", "report card smile"]),
  },
  {
    id: "home",
    title: "Home, Sweet Chaos",
    era: "the family album",
    layout: "reel",
    card: "letter",
    message:
      "Festivals, road trips, loud dinners and louder laughter. Wherever we went, you were the heartbeat of every family photo.",
    photos: pics("home", ["festival lights", "road trip", "with dadi & dada", "sibling squad", "sunday mornings"]),
    // Each letter: 3 photos in /public/photos/home/<folder>/1.jpg, 2.jpg, 3.jpg
    letters: [
      {
        from: "Mom",
        greeting: "My dearest Vaishnavi,",
        message:
          "Twenty-one years ago I held you for the first time, and my whole world rearranged itself around you. Watching you grow into this kind, brave, brilliant woman has been the greatest joy of my life. Keep smiling that smile - the world needs it.",
        sign: "All my love, always - Mom",
        photos: pics("home/mom", ["mom and me", "mom's favourite photo", "us, always"]),
      },
      {
        from: "Brother",
        greeting: "Hey Vaishnavi,",
        message:
          "Partner in crime, official fight-starter, and the person who always has my back. Thanks for every secret kept and every snack stolen. Happy 21st - you're stuck with me forever.",
        sign: "Your favourite (only) brother",
        photos: pics("home/brother", ["sibling chaos", "us then", "us now"]),
      },
    ],
  },
  {
    id: "teen",
    title: "Playlists & Plot Twists",
    era: "the teenage years",
    layout: "scatter",
    card: "stamp",
    message:
      "A playlist for every mood, a diary with a lock, opinions on everything - and a heart that still made time for everyone.",
    photos: pics("teen", ["sweet sixteen", "mirror selfie era", "farewell day", "late-night talks"]),
  },
  {
    id: "squad",
    title: "Partners in Crime",
    era: "friends who became family",
    layout: "stack",
    card: "letter",
    message:
      "The ones who know every inside joke, every secret, every 3am plan. Thank you for collecting such wonderful people.",
    photos: pics("squad", ["the squad", "birthday chaos", "trip of the year", "matching outfits"]),
  },
  {
    id: "white-coat",
    title: "White Coat Dreams",
    era: "now, at twenty-one",
    layout: "reel",
    card: "notebook",
    dentist: true,
    message:
      "Textbooks, lab coats, and the brightest smile in every room. We'd expect nothing less from a future dentist.",
    photos: pics("white-coat", ["first day at college", "white coat moment", "lab life", "study grind", "twenty-one!"]),
  },
];
