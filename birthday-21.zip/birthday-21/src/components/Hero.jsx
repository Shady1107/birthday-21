import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import Envelope from "./Envelope";
import { Arrow, Star, Tooth } from "./Doodles";
import { FROM, FULL_NAME, INTRO, NAME } from "../data/chapters";

const monogram = FULL_NAME.split(" ").map((w) => w[0]).join("");

export default function Hero() {
  const ref = useRef(null);
  const { scrollYProgress: p } = useScroll({ target: ref, offset: ["start start", "end end"] });

  const envY = useTransform(p, [0.2, 0.55], ["0%", "30%"]);
  const titleOpacity = useTransform(p, [0.12, 0.3], [1, 0]);
  const hintOpacity = useTransform(p, [0, 0.08], [1, 0]);
  const starsY = useTransform(p, [0, 1], [0, -160]);

  return (
    <section ref={ref} className="hero">
      <div className="hero__sticky">
        <motion.div className="hero__stars" style={{ y: starsY }} aria-hidden="true">
          <Star className="float" style={{ left: "10%", top: "22%", width: 26 }} />
          <Star className="float" style={{ left: "15%", top: "30%", width: 14 }} />
          <Star className="float" style={{ left: "8%", top: "36%", width: 18 }} />
          <Star className="float" style={{ right: "12%", top: "64%", width: 22 }} />
          <Star className="float" style={{ right: "8%", top: "72%", width: 13 }} />
          <Tooth className="float float--tooth" />
        </motion.div>

        <motion.div className="hero__title" style={{ opacity: titleOpacity }}>
          <motion.p
            className="eyebrow"
            initial={{ opacity: 0, letterSpacing: "0.8em" }}
            animate={{ opacity: 1, letterSpacing: "0.35em" }}
            transition={{ duration: 1.6, ease: "easeOut" }}
          >
            twenty-one years of
          </motion.p>
          <motion.h1
            className="script"
            initial={{ clipPath: "inset(0 100% 0 0)" }}
            animate={{ clipPath: "inset(0 0% 0 0)" }}
            transition={{ duration: 2.2, delay: 0.5, ease: [0.65, 0, 0.35, 1] }}
          >
            {NAME}
          </motion.h1>
        </motion.div>

        <motion.div
          className="hero__envelope"
          style={{ y: envY }}
          initial={{ opacity: 0, scale: 0.9, rotate: -4 }}
          animate={{ opacity: 1, scale: 1, rotate: 0 }}
          transition={{ duration: 1.2, delay: 1.2, ease: [0.22, 1, 0.36, 1] }}
        >
          <Envelope
            progress={p}
            address={`to: ${FULL_NAME}`}
            seal={monogram}
            greeting={`Dear ${NAME},`}
            message={INTRO}
            sign={`xo, ${FROM}`}
          />
        </motion.div>

        <motion.p className="hero__hint" style={{ opacity: hintOpacity }}>
          scroll to open!
          <Arrow className="hero__hint-arrow" />
        </motion.p>
      </div>
    </section>
  );
}
