import { useState } from "react";
import { motion } from "framer-motion";

export default function Polaroid({ src, alt = "", bw, square, tape }) {
  const [failed, setFailed] = useState(!src);
  const classes = ["polaroid", square && "polaroid--square", bw && "polaroid--bw"].filter(Boolean).join(" ");

  return (
    <motion.figure
      className={classes}
      whileHover={{ scale: 1.05, y: -8 }}
      transition={{ type: "spring", stiffness: 260, damping: 18 }}
    >
      {tape && <span className={`tape tape--${tape}`} />}
      <motion.div
        className="polaroid__photo"
        initial={{ filter: "sepia(0.9) brightness(1.8) blur(6px)" }}
        whileInView={{ filter: "sepia(0) brightness(1) blur(0px)" }}
        viewport={{ once: true, amount: 0.5 }}
        transition={{ duration: 2.4, ease: "easeOut" }}
      >
        {failed ? (
          <div className="polaroid__placeholder" />
        ) : (
          <img src={src} alt={alt} loading="lazy" onError={() => setFailed(true)} />
        )}
      </motion.div>
    </motion.figure>
  );
}
