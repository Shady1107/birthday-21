import { useLayoutEffect, useRef, useState } from "react";
import { motion, useScroll, useSpring, useTransform, useVelocity } from "framer-motion";
import Card, { ROMAN } from "./Card";
import Envelope from "./Envelope";
import Polaroid from "./Polaroid";
import Reveal from "./Reveal";
import { Arrow, Star, Tooth } from "./Doodles";

function StageHeader({ stage, index, align = "center" }) {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const numeralY = useTransform(scrollYProgress, [0, 1], [90, -90]);

  return (
    <header ref={ref} className={`stage__header stage__header--${align}`}>
      <motion.span className="stage__numeral" style={{ y: numeralY }} aria-hidden="true">
        {ROMAN[index] ?? index + 1}
      </motion.span>
      <Reveal className="stage__kicker">
        stage {ROMAN[index] ?? index + 1} &middot; {stage.era}
      </Reveal>
      <motion.h2
        className="stage__title script"
        initial={{ clipPath: "inset(0 100% 0 0)" }}
        whileInView={{ clipPath: "inset(0 0% 0 0)" }}
        viewport={{ once: true, amount: 0.6 }}
        transition={{ duration: 1.8, ease: [0.65, 0, 0.35, 1] }}
      >
        {stage.title}
      </motion.h2>
    </header>
  );
}

function Floats({ index }) {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], [-80, 160]);
  const rotate = useTransform(scrollYProgress, [0, 1], [0, 120]);
  const side = index % 2 ? "right" : "left";
  const other = index % 2 ? "left" : "right";

  return (
    <motion.div ref={ref} className="stage__floats" style={{ y }} aria-hidden="true">
      <motion.span style={{ rotate, position: "absolute", [side]: "4%", top: "18%" }}>
        <Star className="float-icon" style={{ width: 26 }} />
      </motion.span>
      <Star className="float" style={{ [side]: "8%", top: "26%", width: 14 }} />
      {index % 3 === 2 ? (
        <Tooth className="float" style={{ [other]: "5%", top: "70%", width: 24 }} />
      ) : (
        <Star className="float" style={{ [other]: "6%", top: "72%", width: 18 }} />
      )}
    </motion.div>
  );
}

/* ---------- Scatter: photos are dealt onto the table as you scroll ---------- */

const SLOTS = [
  { left: 0, top: 3, r: -7 },
  { left: 52, top: 0, r: 5 },
  { left: 3, top: 52, r: 5 },
  { left: 51, top: 55, r: -6 },
  { left: 26, top: 27, r: -2 },
];

function ScatterPhoto({ photo, i, progress, flip }) {
  const slot = SLOTS[i % SLOTS.length];
  const dir = (i % 2 ? 1 : -1) * (flip ? -1 : 1);
  const range = [i * 0.07, 0.4 + i * 0.07];
  const x = useTransform(progress, range, [dir * 320, 0]);
  const y = useTransform(progress, range, [-260, 0]);
  const rotate = useTransform(progress, range, [slot.r + dir * 45, slot.r]);
  const scale = useTransform(progress, range, [1.25, 1]);
  const opacity = useTransform(progress, [range[0], range[0] + 0.12], [0, 1]);

  return (
    <motion.div
      className="collage__item"
      style={{ left: `${slot.left}%`, top: `${slot.top}%`, zIndex: i + 1, x, y, rotate, scale, opacity }}
    >
      <Polaroid src={photo.src} alt={photo.caption} square tape={i % 2 ? "plain" : "gingham"} />
    </motion.div>
  );
}

function Scatter({ stage, index }) {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "center center"] });
  const flip = index % 2 === 1;

  return (
    <section className={`stage stage--scatter ${flip ? "stage--flip" : ""}`}>
      <Floats index={index} />
      <StageHeader stage={stage} index={index} />
      <div className="stage__grid">
        <div ref={ref} className="collage">
          {stage.photos.slice(0, SLOTS.length).map((photo, i) => (
            <ScatterPhoto key={photo.src} photo={photo} i={i} progress={scrollYProgress} flip={flip} />
          ))}
        </div>
        <Reveal tilt={flip ? 2 : -2} delay={0.1} className="stage__card">
          <Card stage={stage} index={index} />
        </Reveal>
      </div>
    </section>
  );
}

/* ---------- Stack: pinned deck, each scroll step flicks the top photo away ---------- */

const FAN = [-4, 5, -7, 3, -2];

function StackPhoto({ photo, i, n, progress }) {
  const step = 0.8 / (n - 1);
  const start = i * step;
  const last = i === n - 1;
  const dir = i % 2 ? 1 : -1;
  const r = FAN[i % FAN.length];
  const x = useTransform(progress, [start, start + step], [i * 6, last ? i * 6 : dir * 220]);
  const y = useTransform(progress, [start, start + step], ["0vh", last ? "0vh" : "-115vh"]);
  const rotate = useTransform(progress, [start, start + step], [r, last ? r : r + dir * 35]);

  return (
    <motion.div className="stack__item" style={{ zIndex: n - i, x, y, rotate }}>
      <Polaroid src={photo.src} alt={photo.caption} tape={i % 2 ? "plain" : "gingham"} />
    </motion.div>
  );
}

function Stack({ stage, index }) {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end end"] });
  const n = stage.photos.length;
  const step = 0.8 / (n - 1);
  const count = useTransform(scrollYProgress, (v) => Math.min(n, Math.floor(v / step) + 1));
  const card = <Card stage={stage} index={index} />;

  return (
    <section ref={ref} className="stage stage--stack" style={{ height: `${n * 60 + 100}vh` }}>
      <div className="stack__sticky">
        <StageHeader stage={stage} index={index} />
        <div className="stage__grid">
          <div className="stack__deck">
            {stage.photos.map((photo, i) => (
              <StackPhoto key={photo.src} photo={photo} i={i} n={n} progress={scrollYProgress} />
            ))}
            <p className="stack__count">
              <motion.span>{count}</motion.span> / {n}
            </p>
          </div>
          <Reveal tilt={index % 2 ? 2 : -2} delay={0.1} className="stage__card stack__card--inline">
            {card}
          </Reveal>
        </div>
      </div>
      <Reveal tilt={-2} className="stack__card--after">
        {card}
      </Reveal>
    </section>
  );
}

/* ---------- Reel: pinned clothesline that slides sideways; photos swing with scroll speed ---------- */

const HANG = [-4, 3, -2, 5, -3];

function ReelPhoto({ photo, i, swing }) {
  const base = HANG[i % HANG.length];
  const rotate = useTransform(swing, (s) => base + s * (i % 2 ? 1 : 0.7));

  return (
    <motion.div className={`reel__item ${i % 2 ? "reel__item--small" : ""}`} style={{ rotate }}>
      <span className="clothespin" />
      <Polaroid src={photo.src} alt={photo.caption} />
    </motion.div>
  );
}

function Reel({ stage, index }) {
  const sectionRef = useRef(null);
  const trackRef = useRef(null);
  const [dist, setDist] = useState(0);

  useLayoutEffect(() => {
    const track = trackRef.current;
    const measure = () => setDist(Math.max(0, track.scrollWidth - window.innerWidth));
    const observer = new ResizeObserver(measure);
    observer.observe(track);
    window.addEventListener("resize", measure);
    measure();
    return () => {
      observer.disconnect();
      window.removeEventListener("resize", measure);
    };
  }, []);

  const { scrollYProgress } = useScroll({ target: sectionRef, offset: ["start start", "end end"] });
  const x = useTransform(scrollYProgress, [0, 1], [0, -dist]);
  const velocity = useVelocity(scrollYProgress);
  const swing = useSpring(useTransform(velocity, [-0.8, 0.8], [10, -10]), { stiffness: 140, damping: 8 });

  return (
    <section ref={sectionRef} className="stage stage--reel" style={{ height: `calc(${dist}px + 100vh)` }}>
      <div className="reel__sticky">
        <motion.div ref={trackRef} className="reel__track" style={{ x }}>
          <div className="reel__intro">
            <StageHeader stage={stage} index={index} align="left" />
            <p className="reel__hint">
              keep scrolling
              <Arrow className="reel__hint-arrow" />
            </p>
          </div>
          <div className="reel__line">
            <span className="reel__string" />
            <span className="reel__lights" />
            {stage.photos.map((photo, i) => (
              <ReelPhoto key={photo.src} photo={photo} i={i} swing={swing} />
            ))}
          </div>
          <div className="reel__end">
            <Card stage={stage} index={index} />
          </div>
        </motion.div>
      </div>
    </section>
  );
}

/* ---------- Letters: pinned envelope opens, letter rises, 3 photos tumble out ---------- */

function LetterEnvelope({ letter, i }) {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end end"] });
  const labelOpacity = useTransform(scrollYProgress, [0, 0.1, 0.9, 1], [0, 1, 1, 0]);

  return (
    <div ref={ref} className="letters__item">
      <div className="letters__sticky">
        <motion.p className="letters__label" style={{ opacity: labelOpacity }}>
          letter {ROMAN[i]} &middot; from {letter.from}
        </motion.p>
        <div className="letters__envelope">
          <Envelope
            progress={scrollYProgress}
            address={`from: ${letter.from}`}
            seal={letter.seal ?? letter.from[0].toUpperCase()}
            greeting={letter.greeting}
            message={letter.message}
            sign={letter.sign}
            photos={letter.photos}
          />
        </div>
      </div>
    </div>
  );
}

function Letters({ letters }) {
  return (
    <section className="stage stage--letters">
      {letters.map((letter, i) => (
        <LetterEnvelope key={letter.from} letter={letter} i={i} />
      ))}
    </section>
  );
}

const LAYOUTS = { scatter: Scatter, stack: Stack, reel: Reel };

export default function Stage({ stage, index }) {
  const Layout = LAYOUTS[stage.layout] ?? Scatter;
  return (
    <>
      <Layout stage={stage} index={index} />
      {stage.letters && <Letters letters={stage.letters} />}
    </>
  );
}
