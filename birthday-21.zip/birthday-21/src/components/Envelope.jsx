import { motion, useTransform } from "framer-motion";
import Polaroid from "./Polaroid";
import { Bow } from "./Doodles";

function EnvelopePhoto({ photo, i, progress }) {
  const start = 0.45 + i * 0.06;
  const t = useTransform(progress, [start, start + 0.3], [0, 1]);
  const lift = useTransform(progress, [start, start + 0.12, start + 0.3], [0, 1, 0]);
  const zIndex = useTransform(progress, (v) => (v < start + 0.12 ? 2 : 6));
  const opacity = useTransform(progress, [start, start + 0.04], [0, 1]);

  return (
    <motion.div className={`env-photo env-photo--${i}`} style={{ "--t": t, "--lift": lift, zIndex, opacity }}>
      <Polaroid src={photo.src} alt={photo.caption} tape={i === 1 ? "gingham" : null} />
    </motion.div>
  );
}

// progress: 0-0.2 flap opens, 0.2-0.55 letter rises, 0.45-0.87 photos come out
export default function Envelope({ progress, address, seal, greeting, message, sign, photos = [] }) {
  const flapRotate = useTransform(progress, [0, 0.2], [0, 180]);
  const flapZ = useTransform(progress, (v) => (v < 0.1 ? 4 : 1));
  const sealOpacity = useTransform(progress, [0, 0.06], [1, 0]);
  const sealScale = useTransform(progress, [0, 0.06], [1, 0.6]);
  const letterY = useTransform(progress, [0.2, 0.55], ["0%", "-92%"]);

  return (
    <div className="envelope">
      <div className="envelope__back" />
      <div className="letter-slot">
        <motion.div className="letter paper" style={{ y: letterY }}>
          <Bow className="letter__bow" />
          <p className="letter__greeting">{greeting}</p>
          <p className="letter__body">{message}</p>
          <p className="letter__sign">{sign}</p>
        </motion.div>
      </div>
      {photos.slice(0, 3).map((photo, i) => (
        <EnvelopePhoto key={photo.src} photo={photo} i={i} progress={progress} />
      ))}
      <div className="envelope__pocket">
        <div className="envelope__pocket-shape" />
        <p className="envelope__to">{address}</p>
      </div>
      <motion.div className="envelope__flap" style={{ rotateX: flapRotate, zIndex: flapZ }}>
        <div className="envelope__flap-shape" />
      </motion.div>
      <motion.div className="seal" style={{ opacity: sealOpacity, scale: sealScale }}>
        {seal}
      </motion.div>
    </div>
  );
}
