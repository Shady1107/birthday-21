const line = { fill: "none", stroke: "currentColor", strokeLinecap: "round", strokeLinejoin: "round" };

export const Star = ({ className, style }) => (
  <svg className={className} style={style} viewBox="0 0 24 24" {...line} strokeWidth="1.3" aria-hidden="true">
    <path d="M12 2.5l2.7 6.1 6.6.6-5 4.4 1.5 6.5L12 16.8 6.2 20.1l1.5-6.5-5-4.4 6.6-.6z" />
  </svg>
);

export const Bow = ({ className }) => (
  <svg className={className} viewBox="0 0 64 64" {...line} strokeWidth="1.8" aria-hidden="true">
    <path d="M32 22c-5-8-17-13-20-7s9 10 20 7z" />
    <path d="M32 22c5-8 17-13 20-7s-9 10-20 7z" />
    <path d="M31 23c-3 10-8 22-13 35M33 23c3 10 8 22 13 35" />
    <circle cx="32" cy="22" r="2.4" />
  </svg>
);

export const Arrow = ({ className }) => (
  <svg className={className} viewBox="0 0 40 40" {...line} strokeWidth="1.8" aria-hidden="true">
    <path d="M30 4c4 12-2 24-20 28" />
    <path d="M16 26l-6 6 8 2" />
  </svg>
);

export const Heart = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" {...line} strokeWidth="1.6" aria-hidden="true">
    <path d="M12 20s-7.5-4.6-7.5-10.2A4.2 4.2 0 0112 7.4a4.2 4.2 0 017.5 2.4C19.5 15.4 12 20 12 20z" />
  </svg>
);

export const Tooth = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" {...line} strokeWidth="1.4" aria-hidden="true">
    <path d="M7 3C4.5 3 3 5 3 7.5c0 2.5 1 4 1.5 6.5.5 3 1 7 2.5 7s1.6-4 2.5-6c.5-1 1-1.5 2.5-1.5s2 .5 2.5 1.5c.9 2 1 6 2.5 6s2-4 2.5-7c.5-2.5 1.5-4 1.5-6.5C21 5 19.5 3 17 3c-2 0-3 1-5 1S9 3 7 3z" />
  </svg>
);

export const Stamp = ({ top, value, bottom, art, className = "" }) => (
  <div className={`stamp ${className}`} aria-hidden="true">
    <div className="stamp__inner">
      <span className="stamp__top">{top}</span>
      <span className="stamp__value">{value}</span>
      <span className="stamp__art">{art}</span>
      <span className="stamp__bottom">{bottom}</span>
    </div>
  </div>
);

export const DentistStamp = ({ surname, className }) => (
  <Stamp
    className={className}
    top={`DR. V. ${surname.toUpperCase()}`}
    value="BDS"
    art={<Tooth />}
    bottom="est. 2005 · loading..."
  />
);
