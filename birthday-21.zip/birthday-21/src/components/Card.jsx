import { Bow, DentistStamp, Heart, Stamp } from "./Doodles";
import { FROM, FULL_NAME, NAME } from "../data/chapters";

export const ROMAN = ["i", "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix", "x", "xi", "xii"];
const SURNAME = FULL_NAME.split(" ").at(-1);

export default function Card({ stage, index }) {
  const { card, era, message, greeting = `Dear ${NAME},`, from = FROM } = stage;
  const dentist = stage.dentist && <DentistStamp surname={SURNAME} className="card__stamp" />;

  if (card === "notebook") {
    return (
      <div className="card notebook paper">
        {dentist}
        <header className="notebook__head">
          <span>{era}</span>
          <span>notes</span>
        </header>
        <h3 className="notebook__title script">{greeting}</h3>
        <p className="notebook__body">{message}</p>
        <p className="notebook__sign">
          with love <Heart className="inline-heart" />
        </p>
      </div>
    );
  }

  return (
    <div className={`card paper ${card === "stamp" ? "card--cream" : "card--blush"}`}>
      {card === "stamp" ? (
        <Stamp
          className="card__stamp"
          top={NAME.toUpperCase()}
          value={ROMAN[index] ?? index + 1}
          art={<Heart />}
          bottom="with love"
        />
      ) : (
        <Bow className="card__bow" />
      )}
      {dentist}
      <p className="card__greeting">{greeting}</p>
      <p className="card__body">{message}</p>
      <p className="card__sign">xo, {from}</p>
    </div>
  );
}
