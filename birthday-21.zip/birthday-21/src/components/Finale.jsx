import { motion } from "framer-motion";
import Polaroid from "./Polaroid";
import Reveal from "./Reveal";
import { DentistStamp, Heart, Tooth } from "./Doodles";
import { BIRTHDAY, FINALE, FINALE_PHOTO, FULL_NAME } from "../data/chapters";

const SURNAME = FULL_NAME.split(" ").at(-1);
const PETALS = Array.from({ length: 16 }, (_, i) => ({
  left: `${(i * 37) % 100}%`,
  size: 10 + ((i * 7) % 12),
  duration: 9 + ((i * 5) % 8),
  delay: -((i * 1.7) % 12),
}));

export default function Finale() {
  return (
    <section className="finale">
      <div className="petals" aria-hidden="true">
        {PETALS.map((p, i) => (
          <span
            key={i}
            className="petal"
            style={{
              left: p.left,
              width: p.size,
              height: p.size,
              animationDuration: `${p.duration}s`,
              animationDelay: `${p.delay}s`,
            }}
          />
        ))}
      </div>
      <Reveal tilt={-1} className="finale__wrap">
        <article className="notebook notebook--page paper">
          <DentistStamp surname={SURNAME} className="finale__stamp" />
          <header className="notebook__head">
            <span>{BIRTHDAY}</span>
            <span>notes</span>
          </header>

          <h2 className="finale__title script">
            <span>Happy 21st</span>
            <span className="finale__title-2">Birthday</span>
          </h2>
          <svg className="finale__swoosh" viewBox="0 0 400 60" fill="none" aria-hidden="true">
            <motion.path
              d="M12 38C120 20 270 16 392 20C300 28 170 42 50 52C120 46 210 40 280 42"
              stroke="currentColor"
              strokeWidth="2.6"
              strokeLinecap="round"
              initial={{ pathLength: 0 }}
              whileInView={{ pathLength: 1 }}
              viewport={{ once: true, amount: 0.8 }}
              transition={{ duration: 1.8, delay: 0.5, ease: "easeInOut" }}
            />
          </svg>

          {FINALE.map((text) => (
            <p key={text} className="notebook__body">
              {text}
            </p>
          ))}

          <div className="finale__bottom">
            <div>
              <p className="finale__margin">
                future Dr. {SURNAME} -<br />
                keep smiling
                <br />
                (professionally) <Tooth className="inline-heart" />
              </p>
              <p className="notebook__sign">
                with love <Heart className="inline-heart" />
              </p>
            </div>
            <Reveal tilt={4} delay={0.3} className="finale__photo">
              <Polaroid src={FINALE_PHOTO} alt="here's to 21" tape="gingham" />
            </Reveal>
          </div>
        </article>
      </Reveal>

      <footer className="footer">
        made with love for {FULL_NAME} &middot; 21 &middot; {BIRTHDAY}
      </footer>
    </section>
  );
}
