import { MotionConfig, motion, useScroll, useSpring } from "framer-motion";
import Hero from "./components/Hero";
import Stage from "./components/Stage";
import Finale from "./components/Finale";
import { stages } from "./data/chapters";

export default function App() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 120, damping: 30 });

  return (
    <MotionConfig reducedMotion="user">
      <motion.div className="progress" style={{ scaleX }} />
      <main className="app">
        <Hero />
        {stages.map((stage, i) => (
          <Stage key={stage.id} stage={stage} index={i} />
        ))}
        <Finale />
      </main>
    </MotionConfig>
  );
}
